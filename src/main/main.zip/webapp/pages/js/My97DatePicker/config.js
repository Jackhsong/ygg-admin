var langList = 
[
    {name:'zh-cn',	charset:'UTF-8'},
    {name:'en',	charset:'UTF-8'},
	{name:'zh-tw',	charset:'UTF-8'}
];

var skinList = 
[
    {name:'whyGreen',	charset:'UTF-8'},
    {name:'default',	charset:'UTF-8'}
];